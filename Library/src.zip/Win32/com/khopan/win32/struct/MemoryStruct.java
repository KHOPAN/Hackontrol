package com.khopan.win32.struct;

public abstract class MemoryStruct extends Struct {
	public long memoryAddress;
}
