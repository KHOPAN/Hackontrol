package com.khopan.win32.struct.memory;

import com.khopan.win32.struct.MemoryStruct;

public class HPEN extends MemoryStruct {
	public HPEN() {

	}

	public HPEN(long memoryAddress) {
		this.memoryAddress = memoryAddress;
	}
}
