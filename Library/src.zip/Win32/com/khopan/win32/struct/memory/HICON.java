package com.khopan.win32.struct.memory;

import com.khopan.win32.struct.MemoryStruct;

public class HICON extends MemoryStruct {

}
