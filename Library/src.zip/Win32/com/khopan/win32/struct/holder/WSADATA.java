package com.khopan.win32.struct.holder;

public class WSADATA {
	public int wVersion;
	public int wHighVersion;
	public int iMaxSockets;
	public int iMaxUdpDg;
	public String lpVendorInfo;
	public String szDescription;
	public String szSystemStatus;

	public WSADATA() {

	}
}
