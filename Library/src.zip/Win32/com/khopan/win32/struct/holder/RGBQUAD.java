package com.khopan.win32.struct.holder;

public class RGBQUAD {
	public byte rgbBlue;
	public byte rgbGreen;
	public byte rgbRed;
	public byte rgbReserved;

	public RGBQUAD() {

	}
}
