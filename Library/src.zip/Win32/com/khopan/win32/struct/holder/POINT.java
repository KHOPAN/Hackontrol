package com.khopan.win32.struct.holder;

public class POINT {
	public long x;
	public long y;

	public POINT() {

	}

	public POINT(long x, long y) {
		this.x = x;
		this.y = y;
	}
}
