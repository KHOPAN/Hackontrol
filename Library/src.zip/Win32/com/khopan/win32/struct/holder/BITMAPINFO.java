package com.khopan.win32.struct.holder;

public class BITMAPINFO {
	public BITMAPINFOHEADER bmiHeader;
	public RGBQUAD[] bmiColors;

	public BITMAPINFO() {

	}
}
