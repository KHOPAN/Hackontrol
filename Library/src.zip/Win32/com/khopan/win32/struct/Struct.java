package com.khopan.win32.struct;

public abstract class Struct {

}
