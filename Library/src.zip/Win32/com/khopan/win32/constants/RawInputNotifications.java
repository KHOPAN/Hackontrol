package com.khopan.win32.constants;

public interface RawInputNotifications {
	public static final int WM_INPUT = 0x00FF;
	public static final int WM_INPUT_DEVICE_CHANGE = 0x00FE;
}
