package com.khopan.win32.constants;

public interface PaintMessages {
	public static final int WM_DISPLAYCHANGE = 0x007E;
	public static final int WM_ERASEBKGND = 0x0014;
	public static final int WM_NCPAINT = 0x0085;
	public static final int WM_PAINT = 0x000F;
	public static final int WM_PRINT = 0x0317;
	public static final int WM_PRINTCLIENT = 0x0318;
	public static final int WM_SETREDRAW = 0x000B;
	public static final int WM_SYNCPAINT = 0x0088;
}
