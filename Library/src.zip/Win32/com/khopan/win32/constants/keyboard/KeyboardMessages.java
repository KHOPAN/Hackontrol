package com.khopan.win32.constants.keyboard;

public interface KeyboardMessages {
	public static final int WM_GETHOTKEY = 0x0033;
	public static final int WM_SETHOTKEY = 0x0032;
}
